DROP TABLE IF EXISTS `mod_dnsmanager_domains`;
DROP TABLE IF EXISTS `mod_dnsmanager_logs`;
